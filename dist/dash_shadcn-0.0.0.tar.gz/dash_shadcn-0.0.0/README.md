# Dash-Shadcn

Using shadcn-ui components in Dash

```
pip install dash-shadcn
```

